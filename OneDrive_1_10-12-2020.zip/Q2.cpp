//2. Test whether a recursive, iterative or linked - type binary search is faster by testing it on
//arrays of size 1 million, 10 million, and 100 million with arrays that are filled with random
//numbers going from smallest to largest.

#include <iostream>
#include <ctime>
#include <algorithm>
#include<chrono>
#define ll long long
using namespace std;
using namespace std::chrono;

//recursive binarySearch
bool recursive_binarySearch(int* array, int first_num, int last_num, int target)
{

    static int count = 0;
    count++;
    
    int midpoint = (first_num + last_num) / 2;

    //check mid for positive stop
    if (array[midpoint] == target) {
        //cout << "The binarySearch is running for " << count << " times." << "\n";
        return true;
    }
        
    //check mid for negative stop
    if (midpoint == first_num || midpoint == last_num) {
        return false;
    }

    if (target < array[midpoint]) {
        return recursive_binarySearch(array, first_num, midpoint, target);
    }
    else if (target > array[midpoint]) {
        return recursive_binarySearch(array, midpoint, last_num, target);
    }
    
        
}

//iterative
bool iterativeBinarySearch(int* array, int first_num, int last_num, int target) {

    while (first_num <= last_num) {
        int midpoint = (first_num + last_num) / 2;

        if (array[midpoint] == target) {
            return true;
        }
        else if (target > array[midpoint]) {
            first_num = midpoint + 1;
        }
        else {
            last_num = midpoint - 1;
        }
    }
    return false;
}

//linked
class node {
public:
    int value;
    node* next;
};

node* create_newNode(int input_value) {
    node* newNode = new node;
    newNode->value = input_value;
    newNode->next = NULL;
    return newNode;
}

node* Create_linkList_from_array(int* array, int arr_size) {
    node* current_Node = NULL;
    node* first_Node = NULL;
    node* last_Node = NULL;

    for (int i = 0; i < arr_size; i++) {
        
        if (current_Node == NULL) {
            
            current_Node = create_newNode(*(array + i));
            if (first_Node == NULL) {
                first_Node = current_Node;
            }

            if (last_Node != NULL) {
                last_Node->next = current_Node;
            }
        }
        last_Node = current_Node;
        current_Node = current_Node->next;
    }
    return first_Node;
}

node* midpoint_function(node* start, node* last)
{
    if (start == NULL) return NULL;

    node* move_slow = start;
    node* move_fast = start->next;

    while (move_fast != last) {
        
        move_fast = move_fast->next;
        
        if (move_fast != last) {

            move_slow = move_slow->next;
            move_fast = move_fast->next;
        }
    }

    return move_slow;
}

node* liked_binarySearch(node* current_node, int target) {
    node* first = current_node;
    node* last = NULL;

    while (last != first || last == NULL) {
        
        node* midpoint = midpoint_function(first, last);

        if (midpoint == NULL) return NULL;

        if (midpoint->value == target) return midpoint;

        if (midpoint->value < target) {
            first = midpoint->next;
        }
        else {
            last = midpoint;
        }
    }
    return NULL;
}

int main() {
	const int size = 10000000;//10000000 and 100000000
 
	srand(time(NULL));
    int target = rand() % size + 3244589;
    cout << "Target : " << target << "\n\n"; 

	//size1 = 1 million
    int* array1= new int[size];
    for (int i = 0; i < size; i++) {
        array1[i] = (rand() % size + 3244589);
    }

	sort(array1, array1 + size);
    
    //recursive binarySearch
    cout << "1. Recursive binarySearch: " << "\n";
    auto begin_recursive_binarySearch = high_resolution_clock::now();
    
    if (recursive_binarySearch(array1, 0, size - 1, target)) {
        cout << "Match! Search from " << array1[0] << " to " << array1[size - 1] << endl;
        cout << "The target: " << target << " is in the array." << "\n";
    }
    else {
        cout << "Sorry, there is no match to the target: " << target << "\n";
    }
    auto end_recursive_binarySearch = high_resolution_clock::now();
    auto time_for_recursive_binarySearch = duration_cast<microseconds>(end_recursive_binarySearch - begin_recursive_binarySearch);
    
    cout << "Time for recursive binarySearch: " << time_for_recursive_binarySearch.count() << " micro seconds!" << "\n\n";

    //iterative BinarySearch
    cout << "2. Iterative binarySearch: " << "\n";
    auto begin_iterative_binarySearch = high_resolution_clock::now();
    
    if (iterativeBinarySearch(array1, 0, size - 1, target)) {
        cout << "Match! Search from " << array1[0] << " to " << array1[size - 1] << endl;
        cout << "The target: " << target << " is in the array." << "\n";
    }
    else {
        cout << "Sorry, there is no match to the target: " << target << "\n";
    }
    auto end_iterative_binarySearch = high_resolution_clock::now();
    auto time_for_iterative_binarySearch = duration_cast<microseconds>(end_iterative_binarySearch - begin_iterative_binarySearch);

    cout << "Time for iterative binarySearch: " << time_for_iterative_binarySearch.count() << " micro seconds!" << "\n\n";
    
    //LinkedList BinarySearch
    cout << "3. LinkedList BinarySearch: " << "\n";
    node* current_node_array = Create_linkList_from_array(array1, size);

    auto begin_LinkedList_binarySearch = high_resolution_clock::now();
    if (liked_binarySearch(current_node_array, target) == NULL) {
        cout << "Sorry, there is no match to the target: " << target << "\n";
    }
    else {
        cout << "Match! Search from " << array1[0] << " to " << array1[size - 1] << endl;
        cout << "The target: " << target << " is in the array." << "\n";
    }
    auto end_LinkedList_binarySearch = high_resolution_clock::now();
    auto time_for_LinkedList_binarySearch = duration_cast<microseconds>(end_LinkedList_binarySearch - begin_LinkedList_binarySearch);

    cout << "Time for LinkedList binarySearch: " << time_for_LinkedList_binarySearch.count() << " micro seconds!" << endl;


    return 0;
}
