#include <iostream>
using namespace std;

//First thing that we do is create the class Node
class Node {
public:
	int key;
	Node* link;
};

//Print function to output the list
void print(Node* node) {
	while (node != NULL) {
		cout << node->key << " ";
		node = node->link;
	}
	cout << '\n';
}

//We create the add function which allows us to insert data
void add(Node** head, int data) {
	//We create a new node and we assign data at key and NULL at link
	Node* new_Node = new Node;
	new_Node->key = data;
	new_Node->link = NULL;

	//creating the temp node
	Node* temp;

	if (*head == NULL) {
		*head = new_Node;
	}
	else {
		//if *head != Null, then we assign *head to our temp node
		temp = *head;
		//while temp node points to another node 
		while (temp->link != NULL) {
			temp = temp->link;
		}
		temp->link = new_Node;
	}
}

//Sort function to sort odd and even numbers 
void SortOddThenEven(Node** head) {
	Node* even = NULL;
	Node* odd = NULL;
	Node* temp = *head;

	while (temp != NULL) {
		// here we check if key is odd or even
		if ((temp->key) % 2 != 0)   //if key is odd, then insert it in the odd list
			add(&odd, temp->key);
		else    // if key is not odd, then insert it in the even list
			add(&even, temp->key);
		temp = temp->link;
	}

	*head = odd;
	temp = odd;
	while (temp->link != NULL)
		temp = temp->link;
	temp->link = even;
}

int main() {
	cout << "			Program to sort all odd numbers first and then all the even ones!!" << endl << endl;
	int lastNum;
	cout << "Please enter the last number of the list: ";
	cin >> lastNum;
	cout << endl;
	Node* head = NULL;

	//Inserting numbers up to k
	for (int i = 1; i <= lastNum; i++) {
		add(&head, i);
	}

	// printing the list before sorting
	cout << "Before sorting : ";
	print(head);
	cout << endl;

	SortOddThenEven(&head);
	// printing the list after sorting
	cout << "After sorting : ";
	print(head);
	return 0;
}