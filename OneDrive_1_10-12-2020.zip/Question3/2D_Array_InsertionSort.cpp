//Insertion Sort

#include <iostream>
using namespace std;

int main() {
	//We create a 2D array
	int Two_D_Array[3][5] = {
		{8,5,1,2,4},
		{50,20,90,60,30},
		{300,900,100,600,800}
	};
	//We find the number of total rows by dividing the size of the entire array with the size of the first row
	int RowsNumber = sizeof(Two_D_Array) / sizeof(Two_D_Array[0]);

	//We find the number of total columns by dividing the size of the first row with the size of the first element in the first row
	int ColumnsNumber = sizeof(Two_D_Array[0]) / sizeof(Two_D_Array[0][0]);

	//Creating variables that we'll use later on
	int i, j, h, p, q, tmp_value;

	cout << "			   Program that sorts each row of a 2D Array using Insertion Sort\n" << endl;

	//Printing the array before being sorted
	cout << "The 2D array before being sorted: " << endl;
	for (p = 0; p < RowsNumber; p++) {

		for (q = 0; q < ColumnsNumber; q++) {
			cout << Two_D_Array[p][q] << " ";
		}
		cout << endl;
	}
	cout << endl;

	//We need 3 for loops in order to perform the insertion sort of a 2D array
	//for loop to go over the rows
	for (h = 0; h < RowsNumber; h++) {

		//for loop to perform the upcoming loop repeatedly until the whole row is sorted
		for (i = 1; i < ColumnsNumber; i++) {
			tmp_value = Two_D_Array[h][i];				//We store the current value to a temp value

			//loop that assigns the value of the previous element to the current one if the value of the previous element is greater than the value stored in the temp value
			for (j = i; j >= 1 && Two_D_Array[h][j - 1] > tmp_value; j--) {
				Two_D_Array[h][j] = Two_D_Array[h][j - 1];
			}
			Two_D_Array[h][j] = tmp_value;				//We assign temp value to Arr[h][j] if the value of Arr[h][j - 1] is not greater than the value of temp value
		}
	}
	//We need 2 for loops to output the final result
	//Printing the array after being sorted
	cout << "The 2D array after being sorted:" << endl;
	for (p = 0; p < RowsNumber; p++) {

		for (q = 0; q < ColumnsNumber; q++) {
			cout << Two_D_Array[p][q] << " ";
		}
		cout << endl;
	}
}