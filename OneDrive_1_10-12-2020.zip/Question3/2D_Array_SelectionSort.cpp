//Selection Sort

#include <iostream>
using namespace std;

int main() {
	//We create a 2D array
	int Two_D_Array[3][5] = {
		{3,1,5,2,4},
		{300,100,400,500,200},
		{30,50,10,40,20}
	};

	//We find the number of total rows by dividing the size of the entire array with the size of the first row
	int RowsNumber = sizeof(Two_D_Array) / sizeof(Two_D_Array[0]);

	//We find the number of total columns by dividing the size of the first row with the size of the first element in the first row
	int ColumnsNumber = sizeof(Two_D_Array[0]) / sizeof(Two_D_Array[0][0]);

	//We create a temporary index
	int tempIndex;

	cout << "			   Program that sorts each row of a 2D Array using Selection Sort\n" << endl;

	//Printing the array before being sorted
	cout << "The 2D array before being sorted: " << endl;
	for (int p = 0; p < RowsNumber; p++) {

		for (int h = 0; h < ColumnsNumber; h++) {
			cout << Two_D_Array[p][h] << " ";
		}
		cout << endl;
	}
	cout << endl;

	//We need 3 for loops in order to perform the selection sort of a 2D array
	//for loop to go over the rows
	for (int q = 0; q < RowsNumber; q++) {

		//for loop to avoid searching the elements that are already sorted
		for (int i = 0; i < ColumnsNumber - 1; i++) {

			tempIndex = i;

			//We search throughout the row to find a smaller number than the current one
			for (int j = i; j < ColumnsNumber; j++) { 
				 
				if (Two_D_Array[q][j] < Two_D_Array[q][tempIndex])
					tempIndex = j;
			}
			//Here we assign the temp value, which is the smallest to the [q][i] position which is the left most position of the elements that are not sorted
			int tmp_value = Two_D_Array[q][tempIndex];
			Two_D_Array[q][tempIndex] = Two_D_Array[q][i];
			Two_D_Array[q][i] = tmp_value;
		}
	}
	//Printing the array after being sorted
	cout << "The 2D array before after sorted: " << endl;
	for (int p = 0; p < RowsNumber; p++) {

		for (int h = 0; h < ColumnsNumber; h++) {
			cout << Two_D_Array[p][h] << " ";
		}
		cout << endl;
	}
	return 0;
}