//Bubble Sort

#include <iostream>
using namespace std;

int main() {
	//We create a 2D array
	int Two_D_Array[3][5] = {
		{3,1,5,2,4},
		{300,100,400,500,200},
		{30,50,10,40,20}
	};


	//We find the number of total rows by dividing the size of the entire array with the size of the first row
	int RowsNumber = sizeof(Two_D_Array) / sizeof(Two_D_Array[0]);

	//We find the number of total columns by dividing the size of the first row with the size of the first element in the first row
	int ColumnsNumber = sizeof(Two_D_Array[0]) / sizeof(Two_D_Array[0][0]);

	//We create a temporary value to be able to swap elements inside the array
	int temp;


	//Creating variables that we'll use later on
	int p, q, i, j, h;

	cout << "			   Program that sorts each row of a 2D Array using Bubble Sort\n" << endl;
	
	//Printing the array before being sorted
	cout << "The 2D array before being sorted: " << endl;
	for (p = 0; p < RowsNumber; p++) {

		for (q = 0; q < ColumnsNumber; q++) {
			cout << Two_D_Array[p][q] << " ";
		}
		cout << endl;
	}
	cout << endl;


	//We need 3 for loops in order to perform the bubble sort of a 2D array
	//for loop to go over the rows
	for (h = 0; h < RowsNumber; h++) {
		//for loop to perform the swapping that happens in the third loop repeatedly until the whole row is sorted
		for (i = 0; i < ColumnsNumber - 1; i++) {

			//for loop to perform the swapping only once for the whole row
			for (j = 0; j < ColumnsNumber - 1 - i; j++) {

				if (Two_D_Array[h][j] > Two_D_Array[h][j + 1]) {
					//Here we swap the elements if the upcoming element is larger than the current one
					temp = Two_D_Array[h][j];
					Two_D_Array[h][j] = Two_D_Array[h][j + 1];
					Two_D_Array[h][j + 1] = temp;
				}
			} 
		}
	}
	//We need 2 for loops to output the final result

	//Printing the array after being sorted
	cout << "The 2D array after being sorted:" << endl;
	for (p = 0; p < RowsNumber; p++) {

		for (q = 0; q < ColumnsNumber; q++) {
			cout << Two_D_Array[p][q] << " ";
		}
		cout << endl;
	}
	return 0;
}