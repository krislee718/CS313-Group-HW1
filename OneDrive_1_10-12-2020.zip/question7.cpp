#include <iostream>
#include <string.h>
#include <time.h>
#include <vector>
#include <ctime>
#include <chrono>
#include <list>

using namespace std;

//1. Test whether a vector or a list is faster by timing them via:
 //    a.Filling them with random numbers
 //    b.Filling them with random strings(use ascii)
 //    c.Doing the above with move semantics when filling with random strings

//7. Create your own vector and list. Time it similar to question #1

string onlyLetter();

int main()
{
    int length = 10000;
    srand((unsigned)time(NULL));
    cout << "This is Question #7" << endl;
    cout << "This is tested with length of :" << length << endl << endl;

    auto startv = chrono::high_resolution_clock::now();
    vector<long>myvector;
    for (int i = 0; i < length; i++) {
        srand((unsigned)time(NULL));
        myvector.push_back((long)rand());
    }
    auto endv = chrono::high_resolution_clock::now();
    auto durationv = chrono::duration_cast<::chrono::microseconds>(endv - startv).count();
    cout << "This is time for vector of random long: " << durationv << "microseconds" << endl;
    


    auto startL = chrono::high_resolution_clock::now();
    list<long>myIntlist;
    for (int i = 0; i < length; i++) {
        srand((unsigned)time(NULL));
        myIntlist.push_back((long)rand());
    }
    auto endL = chrono::high_resolution_clock::now();
    auto durationL = chrono::duration_cast<::chrono::microseconds>(endL - startL).count();
    cout << "This is time for list of random long: " << durationL << "microseconds" << endl;


    cout << endl << endl << endl << endl;



    auto startStringV = chrono::high_resolution_clock::now();
    vector<string>myStringvector;

    for (int i = 0; i < length; i++) {
        myStringvector.push_back(std::move(onlyLetter()));
    }

    auto endStringV = chrono::high_resolution_clock::now();
    auto durationOfStringV = chrono::duration_cast<::chrono::microseconds>(endStringV - startStringV).count();
    cout << "This is time for vector of random STRING with only letters: " << durationOfStringV << "microseconds" << endl;

 

    auto startStringL = chrono::high_resolution_clock::now();
    list<string>myStringlist;

    for (int i = 0; i < length; i++) {
        myStringlist.push_back(std::move(onlyLetter()));
    }

    auto endStringL = chrono::high_resolution_clock::now();
    auto durationOfStringL = chrono::duration_cast<::chrono::microseconds>(endStringL - startStringL).count();
    cout << "This is time for list of random STRING with only letters: " << durationOfStringL << "microseconds" << endl;


    cout << endl << endl;


    return 0;
}


string onlyLetter() {
    string x;
    for (int i = 0; i < 25; i++) {
        x += (rand() % 25 + 65||rand() %25 +97);
    }
    return x;
}
