//8. Create a template class that effectively finds all possibilities of a list of random numbers that adds to some s.

#include <iostream>
#include <vector>
#include <algorithm>
#include <ctime>
using namespace std;

template <class T>
void Finding_process(T current_pos, T target, T sum, vector<T>& input_list, vector<T>& answer_list)
{
	
	//if sum = target, print out
	if (sum == target)
	{
		for (int i = 0; i < answer_list.size(); i++)
		{
			cout << answer_list[i] << " ";
		}
		cout << endl;	
		return;
	}

	//traversal the array to add sum until it hits the target
	for (int i = current_pos; i < input_list.size(); i++)
	{
		//if sum hasn't hit the target, then pass
		if (sum + input_list[i] > target) continue;

		//ensure my smallest number is 1, and there is no repetitive number in each outcome.
		//if there aren't, then pass
		if (i && input_list[i] == input_list[i - 1] && i > current_pos) continue;

		//put one finding number into answer list
		answer_list.push_back(input_list[i]);

		//recursively finding the number by adding 1 on i to move to next position. 
		Finding_process(i + 1, target, sum + input_list[i], input_list, answer_list);

		//after finding all number the Finding_process will hit the first if-statement then print out the outcome
		//then use pop_back to delete the previous data since the outside forloop is going to move to next i. 
		answer_list.pop_back();
	}

}

template <class T>
void Find_numbers(vector<T> input_list, T target)
{
	// Sort the given elements 
	sort(input_list.begin(), input_list.end());

	//to store the answers
	vector<T> answer_list;
	
	//call to find numbers
	//taking 1. current position = 0 
	//       2. target
	//		 3. sum = 0
	//		 4. input_list: find possible outcome from this list
	//       5. answer_list: store answers
	Finding_process (0, target, 0, input_list, answer_list);
}


int main() {

	int target = 50;
	int size = 10;
	vector<int> input_list = {};
	
	/* initialize random seed: */
	srand(time(NULL));
	
	//write rand number into verctor
	for (int i = 0; i < 10; i++)
	{
		//fill up rand number between 1 to 20;
		input_list.push_back(rand() % 20 + 1);
	}

	cout << "target: " << target << "\n\n";
	cout << "random list number: " << "\n\n";
	for (int i = 0; i < 10; i++)
	{
		cout << input_list[i] << " ";
	}
	cout << "\n\n";
	cout << "Here are all possible outcomes of sum is " << target << " : "<< " \n\n";

	Find_numbers <int> (input_list, target);
	
	return 0;
}
