#include <iostream>
#include <time.h>
#include <ctime>
#include <chrono>

using namespace std;

//***************************************************************************************
//Compare the times it takes to sort a random array vs a linked list with a bubble sort.


struct Node
{
	int value;
	Node* next;
};


void addNode(Node** h, int v);
void printArray(int* array, int size);
void printNode(Node* n);
void bubbleSortNode(Node* head);
void bubbleSortArray(int* array, int size);

template <typename T>
void swap(T* one, T* two);
void swapNode(Node* one, Node* two);


int main()
{
	int number = 100000;

	srand((unsigned)time(NULL));
	int* myArray = new int[number];
	for (int i = 0; i < number; i++) {
		int x = rand() % 10000;
		myArray[i] = x;
	}

	cout << "Size :" << number << endl << endl;

	auto startA = chrono::high_resolution_clock::now();
	bubbleSortArray(myArray, number);
	auto endA = chrono::high_resolution_clock::now();
	auto durationA = chrono::duration_cast<::chrono::microseconds>(endA - startA).count();
	cout << "The bubble sort in array: " << durationA << "microseconds" << endl <<endl;
	

	Node* head = nullptr;
	srand((unsigned)time(NULL));
	for (int i = 0; i < number; i++) {
		int x = rand() % 10000;
		addNode(&head, x);
		
	}

	//printNode(head);
	auto startL = chrono::high_resolution_clock::now();
	bubbleSortNode(head);
	auto endL = chrono::high_resolution_clock::now();
	auto durationL = chrono::duration_cast<::chrono::microseconds>(endL - startL).count();
	cout << "The bubble sort in Linkedlist: " << durationL << "microseconds" << endl;

	cout << endl << endl << endl << endl;
	
	//printNode(head);

	return 0;
}


void addNode(Node** h, int v) {

	Node* node = new Node();
	node->value = v;
	node->next = nullptr;
	Node* current;
	// if head is empty set created node to head
	if (*h == nullptr) {
		*h = node;
		current = node;
	}
	 else {
		current = *h;
		//while next is not pointing to empty keep moving current until is it.
		while (current->next != nullptr) {
			current = current->next;
		}
		current->next = node;
	}
};
//printing
void printNode(Node* n) {
	while (n != nullptr) { // while node is not empty, print value of the node and set node to node->next
		cout << n->value << " ";
		n = n->next;
	}
	cout << endl;
}
// swap nodes
void swapNode(Node* one, Node* two) {
	int temp = one->value;
	one->value = two->value;
	two->value = temp;
}

void bubbleSortNode(Node* head) {

	Node* h = head;			//set h to head	
	Node* n = head->next;	//set n to next

	for (h = head; h->next != nullptr; h = h->next) { //while h-> is not null, keep h= h->next( same logic to i=0, i++)
		for (n = h->next; n != nullptr; n = n->next) { // if h =0 n =1 checking the value of next value of head
			if (h->value > n->value) { // compare and swap if h is bigger
				swapNode(h, n);
			}
		}
	}
}

//swap for array
template <typename T>
void swap(T* one, T* two) {
	int temp = *one;
	*one = *two;
	*two = temp;
};


void bubbleSortArray(int* array, int size)
{
	for (int i = 0; i < size; i++) { //i iterating o to size
		for (int k = 0; k < size - i - 1; k++) {	// k iterating size-i-1 last place in array is sorted size decresses
			if (array[k] > array[k + 1]) {          // swap is k is bigger than k+1
				swap(array[k], array[k + 1]);
			}
		}
	};
}

void printArray(int* array, int size) {
	for (int i = 0; i < size; i++) {
		cout << array[i] << " ";
	}
};