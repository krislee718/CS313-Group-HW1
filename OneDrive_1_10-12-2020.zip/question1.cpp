#include <iostream>
#include <string.h>
#include <time.h>
#include <vector>
#include <ctime>
#include <chrono>
#include <list>

using namespace std;

//1. Test whether a vector or a list is faster by timing them via:
 //    a.Filling them with random numbers
 //    b.Filling them with random strings(use ascii)
 //    c.Doing the above with move semantics when filling with random strings


string randString(); 

int main()
{
    int length = 3000000;
    srand((unsigned)time(NULL));

    cout << "This is tested with length of :" << length << endl << endl;

    auto startv = chrono::high_resolution_clock::now();
    vector<int>myIntvector;
    for (int i = 0; i < length; i++) {
        srand((unsigned)time(NULL));
        myIntvector.push_back(rand() % 10000);
    }
    auto endv = chrono::high_resolution_clock::now();
    auto durationv = chrono::duration_cast<::chrono::microseconds>(endv - startv).count();
    cout << "This is time for vector of random INT: " << durationv << "microseconds" << endl;



    auto startL = chrono::high_resolution_clock::now();
    list<int>myIntlist;
    for (int i = 0; i < length; i++) {
        srand((unsigned)time(NULL));
        myIntlist.push_back(rand() % 10000);
    }
    auto endL = chrono::high_resolution_clock::now();
    auto durationL = chrono::duration_cast<::chrono::microseconds>(endL - startL).count();
    cout << "This is time for list of random INT: " << durationL << "microseconds" << endl;


    cout << endl << endl << endl << endl;



    auto startStringV = chrono::high_resolution_clock::now();
    vector<string>myStringvector;

    for (int i = 0; i < length; i++) {
        myStringvector.push_back(std::move(randString()));
    }

    auto endStringV = chrono::high_resolution_clock::now();
    auto durationOfStringV = chrono::duration_cast<::chrono::microseconds>(endStringV - startStringV).count();
    cout << "This is time for vector of random STRING: " << durationOfStringV << "microseconds" << endl;



    auto startStringL = chrono::high_resolution_clock::now();
    list<string>myStringlist;

    for (int i = 0; i < length; i++) {
        myStringlist.push_back(std::move(randString()));
    }

    auto endStringL = chrono::high_resolution_clock::now();
    auto durationOfStringL = chrono::duration_cast<::chrono::microseconds>(endStringL - startStringL).count();
    cout << "This is time for list of random STRING: " << durationOfStringL << "microseconds" << endl;


    cout << endl << endl;


    return 0;
}


string randString() {
    string x;
    for (int i = 0; i < 25; i++) {
        x += (rand() % 98 + 33);
    }
    return x;
}