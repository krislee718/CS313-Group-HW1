//5.
//Create a multi-level sort. For instance, for all selections of n > 10 you do sort X and
//within sort X, when you have a situation with n < 10 you do sort Y.Be creative.
//Time your sort against two ��reasonably comparable�� sorts
//(you may use libraries for the ��reasonably comparable sorts��).

#include <iostream>
#include <ctime>
#include <chrono>
#include <algorithm>
#include <vector>

using namespace std;
using namespace std::chrono;

template <typename Func>
long long TimeFunc(Func f)
{
	auto begin = high_resolution_clock::now();	
	f();
	auto end = high_resolution_clock::now();

	return duration_cast<microseconds>(end - begin).count();
}

//swap
void swap(int* a, int* b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

//bubble sort
void bubble_sort(int array[], int size)
{
    for (int i = 0; i < size - 1; i++)
    {
        for (int j = 0; j < size - i - 1; j++)
        {
            if (array[j] > array[j + 1])
            {
                swap(&array[j], &array[j + 1]);
            }
        }
    }
}

//Bubble sort for linked list
//linked
class node {
public:
    int value;
    node* next;
};

node* create_newNode(int input_value) {
    node* newNode = new node;
    newNode->value = input_value;
    newNode->next = NULL;
    return newNode;
}

void swap_node(node* a, node* b)
{
    int temp = a->value;
    a->value = b->value;
    b->value = temp;
}

node* Create_linkList_from_array(int* array, int arr_size, int start) {
    node* current_Node = NULL;
    node* first_Node = NULL;
    node* last_Node = NULL;

    for (int i = start; i < arr_size; i++) {

        if (current_Node == NULL) {

            current_Node = create_newNode(*(array + i));
            if (first_Node == NULL) {
                first_Node = current_Node;
            }

            if (last_Node != NULL) {
                last_Node->next = current_Node;
            }
        }
        last_Node = current_Node;
        current_Node = current_Node->next;
    }
    return first_Node;
}

//bubble sort for linked list
void Bubble_linked_list(node* input_node, int size)
{
    node* first_node = input_node;
    node* store_node = NULL;
    int count = 0;
    
    //check if it's empty
    if (first_node == NULL) return;

    store_node = input_node;
    //bubble
    while (first_node != NULL)
    {
        if (first_node->value > first_node->next->value)
        {
            swap_node(first_node, first_node->next);
        }
        first_node = first_node->next;

        //how many times it goes back to the front and do the bubble again
        if (first_node->next == NULL)
        {
            first_node = store_node;
            count++;
        }

        //check all of node then break
        if (count == size) break;
    }
}

void combine_two_array(int arr1[], int size, int arr1_size, int arr2[], int arr2_size)
{
    //An array to store numbers from array 1 and 2
    int* combine_array = new int[size];
    
    int i = 0; //i = count the current position of array1
    int j = 0; //j = count the current position of array2
    int k = 0; //k = count the current position of new comine array

    while (i < arr1_size && j < arr2_size)
    {
        //if the number in first array is less than or equal to the number in second array
        if (arr1[i] <= arr2[j])
        {
            //combuine array take the number from array1
            combine_array[k] = arr1[i];
            i++; //array1 move to next postion
            k++; //combine array move to next position
        }
        else {

            //if not, means array2 has smaller number
            //combuine array take the number from array2
            combine_array[k] = arr2[j]; 
            j++; //array2 move to next postion
            k++; //combine array move to next position
        }
    }

    //Note: arr1 and arr2 has to be sorted
    //if array1 has longer length, then append rest of number to combine array
    while (i < arr1_size)
    {
        combine_array[k] = arr1[i];
        k++;
        i++;
    }
        
    //if array2 has longer length, then append rest of number to combine array
    while (j < arr2_size)
    {
        combine_array[k] = arr2[j];
        k++;
        j++;
    }
}

//speical sort, size > 10 = > bubble sort, size < 10 = > bubble sort with linked list
void special_sort(int* input_array, int size)
{
    //if size is 0, then nothing to sort. 
    if (size <= 0) return;
    
    //if size < 10, then use bubble sort with linked list to sort it.
    else if (size < 10)
    {
        node* move_node = Create_linkList_from_array(input_array, size, 0); //note: begin at pos 0 to create nodes
        Bubble_linked_list(move_node, size);
    }

    // if the size is between 10 to 19, means 
    //first 10 numbers => bubble sort, rest of number (size - 10) => bubble sort for linked list
    else if (size <= 19)
    {
        //bubble sort take care first 10
        bubble_sort(input_array, 10);

        //bubble sort for linked list take care rest of numbers
        node* move_node_2 = Create_linkList_from_array(input_array, size, 10); //note: begin at pos 10 to create nodes
        Bubble_linked_list(move_node_2, size);

        //covert linked_list to array
        int* linked_array = new int[size - 10];
        int count = 0;
        while (move_node_2 != NULL)
        {
            linked_array[count] = move_node_2->value;
            move_node_2 = move_node_2->next;
            count++;
        }
      
        //input_array = arr1
        //10 = arr1 size
        //linked_array = arr2
        //size - 10 = arr2 size
        combine_two_array(input_array, size, 10, linked_array, size - 10);
    }
    else {
        
        //bubble sort take care numbers all the way to the size - 9
        bubble_sort(input_array, size - 9);
        
        //bubble sort with linked list take care rest of numbers
        node* move_node_3 = Create_linkList_from_array(input_array, size, size - 9); //note: begin at pos (size - 9) to create nodes 
        Bubble_linked_list(move_node_3, size);

        //covert linked_list to array
        int* linked_array_2 = new int[9];
        int count_2 = 0;
       
        while (move_node_3 != NULL)
        {
            linked_array_2[count_2] = move_node_3->value;
            move_node_3 = move_node_3->next;
            count_2++;
        }

        //input_array = arr1
        //size - 9 = arr1 size
        //linked_array_2 = arr2
        //9 = arr2 size
        combine_two_array(input_array, size, size - 9, linked_array_2, 9 );
    }
}

int main()
{
    int size;
    
    cout << "size: ";
    cin >> size;
    
    int* array1 = new int[size];
    int* array2 = new int[size];
    int* array3 = new int[size];
    srand(time(NULL));

    //fill up with random numbers
    for (int i = 0; i < size; i++) {
        array1[i] = (rand() % 100 + 0);
        array2[i] = array1[i];
        array3[i] = array1[i];
    }

    //Time sort random number with only using bubble sort
    auto array1_time = TimeFunc([&]() {bubble_sort(array1, size); });
    cout << "Only bubble sort: " << array1_time << " micro seconds!" << "\n\n";
   
    //Time sort random number with only using bubble sort with linked list
    auto begin = high_resolution_clock::now();
    node* array2_node = Create_linkList_from_array(array2, size, 0);
    Bubble_linked_list(array2_node, size);
    auto end = high_resolution_clock::now();
    
    auto array2_time = duration_cast<microseconds>(end - begin).count();
    cout << "only bubble sort with linked list: " << array2_time << " micro seconds!" << "\n\n";
   
    //Time sort random number with special sorting way: 
    //when size > 10 => use bubble sort
    //then when size is < 10 => use bubble sort with linked list
    auto array3_time = TimeFunc([&]() {special_sort(array3, size); });
    cout << "special sort: " << array3_time << " micro seconds!" << "\n\n";
    
    return 0;
}

